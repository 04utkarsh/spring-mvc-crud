package springmvc_example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;

import springmvc_example.model.User;


@Repository
public class UserDaoImpl implements UserDao{
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException
	{
		
		  this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	public List<User> listAllUsers() {
		// TODO Auto-generated method stub
		String sql="select id,name,designation,employeeid from users";
		
		List<User> list =namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null),new UserMapper());
		return list;
	}
	 private SqlParameterSource getSqlParameterByModel(User user){
		  MapSqlParameterSource paramSource = new MapSqlParameterSource();
		  if(user != null) {
			 paramSource.addValue("id",user.getId());
			 paramSource.addValue("name",user.getName()); 
			 paramSource.addValue("designation",user.getDesignation()); 
			 paramSource.addValue("employeeid",user.getEmployeeid()); 
		  }
		return paramSource;  
	 }
	 private static final class UserMapper implements RowMapper<User>{
		 public User mapRow(ResultSet rs, int rowNum)throws SQLException
		 {
			 User user =new User();
			 
			 user.setId(rs.getInt("id"));
			 user.setName(rs.getString("name"));
			 user.setDesignation(rs.getString("designation"));
			 user.setEmployeeid(rs.getString("employeeid"));
			 return user;
			 }
		 }

	public void addUser(User user) {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO users(name,designation,employeeid) VALUES(:name, :designation, :employeeid)";
				  
				  namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(user));
		
	}

	public void updateUser(User user) {
		// TODO Auto-generated method stub
		  String sql = "UPDATE users SET name = :name, designation = :designation, employeeid = :employeeid WHERE id = :id";
				    
				    namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(user));
	}

	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		 String sql = "DELETE FROM users WHERE id = :id";
		  
		  namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new User(id)));
	}

	public User findUserById(int id) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM users WHERE id = :id";
		  
		  return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new User(id)), new UserMapper());
	}

}

